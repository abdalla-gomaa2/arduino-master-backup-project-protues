#include <Arduino.h>
#line 1 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Slave1arduino\\Slave1arduino.ino"
#include <Wire.h>

#define SLAVE_ADDRESS 8 
#define LED1_PIN 10     
#define LED2_PIN 8      

#line 7 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Slave1arduino\\Slave1arduino.ino"
void setup();
#line 17 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Slave1arduino\\Slave1arduino.ino"
void loop();
#line 21 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Slave1arduino\\Slave1arduino.ino"
void receiveEvent(int bytes);
#line 7 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Slave1arduino\\Slave1arduino.ino"
void setup() {
  Wire.begin(SLAVE_ADDRESS);
  Wire.onReceive(receiveEvent); 
  pinMode(LED1_PIN, OUTPUT); 
  pinMode(LED2_PIN, OUTPUT);
  digitalWrite(LED1_PIN, LOW); 
  digitalWrite(LED2_PIN, LOW);
  Serial.begin(9600); 
}

void loop() {
  
}

void receiveEvent(int bytes) {
  int command = Wire.read();
  Serial.print("Received command: ");
  Serial.println(command);

  if (command == 1) {
    digitalWrite(LED1_PIN, HIGH); 
    digitalWrite(LED2_PIN, LOW);  
  } else if (command == 2) {
    digitalWrite(LED1_PIN, LOW);  
    digitalWrite(LED2_PIN, HIGH); 
  } else if (command == 0) {
    digitalWrite(LED1_PIN, LOW);  
    digitalWrite(LED2_PIN, LOW);  
  }
}
