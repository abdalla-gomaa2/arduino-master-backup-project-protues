#include <Arduino.h>
#line 1 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
#include <Wire.h>

#define SLAVE1_ADDRESS 8  
#define SLAVE2_ADDRESS 9  
#define MASTER_ADDRESS 10 

bool isMaster = false; 

#line 9 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
void setup();
#line 16 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
void loop();
#line 36 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
void receiveEvent(int bytes);
#line 43 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
void takeOverAsMaster();
#line 49 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
void returnToSlaveMode();
#line 56 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
void controlSlave(int slaveAddress);
#line 83 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
bool checkMasterStatus(int masterAddress);
#line 9 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\slavemaster\\slavemaster.ino"
void setup() {
  Wire.begin(SLAVE2_ADDRESS); 
  Wire.onReceive(receiveEvent); 
  Serial.begin(2600); 
  isMaster = false; 
}

void loop() {
  if (!isMaster) {
    
    Wire.beginTransmission(MASTER_ADDRESS);
    if (Wire.endTransmission() != 0) {
      Serial.println("ARD3 is not responding. Taking over as master...");
      takeOverAsMaster();
    }
  } else {
      controlSlave(SLAVE1_ADDRESS);
    if (checkMasterStatus(MASTER_ADDRESS)) {
      Serial.println("ARD3 has recovered. Returning to slave mode...");
      returnToSlaveMode();
    }
  }
  delay(500); }


void receiveEvent(int bytes) {
  int command = Wire.read();
  Serial.print("Received command: ");
  Serial.println(command);
}


void takeOverAsMaster() {
  Wire.begin(); 
  isMaster = true; 
}


void returnToSlaveMode() {
  Wire.begin(SLAVE2_ADDRESS); 
  Wire.onReceive(receiveEvent); 
  isMaster = false;
}


void controlSlave(int slaveAddress) {
  Serial.println("Sending command to ARD1: Turn on LED1");
  Wire.beginTransmission(slaveAddress);
  Wire.write(1); 
  Wire.endTransmission();
  delay(1000);

  Serial.println("Sending command to ARD1: Turn off both LEDs");
  Wire.beginTransmission(slaveAddress);
  Wire.write(0); 
  Wire.endTransmission();
  delay(500);

  Serial.println("Sending command to ARD1: Turn on LED2");
  Wire.beginTransmission(slaveAddress);
  Wire.write(2); 
  Wire.endTransmission();
  delay(1000);

  Serial.println("Sending command to ARD1: Turn off both LEDs");
  Wire.beginTransmission(slaveAddress);
  Wire.write(0); 
  Wire.endTransmission();
  delay(500);
}

// Function to check if ARD3 is responding
bool checkMasterStatus(int masterAddress) {
  Wire.beginTransmission(masterAddress);
  byte error = Wire.endTransmission();
  return (error == 0); 
}
