#include <Arduino.h>
#line 1 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Masterarduino\\Masterarduino.ino"
#include <Wire.h>

#define SLAVE1_ADDRESS 8 
#define SLAVE2_ADDRESS 9  

#line 6 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Masterarduino\\Masterarduino.ino"
void setup();
#line 11 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Masterarduino\\Masterarduino.ino"
void loop();
#line 25 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Masterarduino\\Masterarduino.ino"
void controlSlave(int slaveAddress);
#line 52 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Masterarduino\\Masterarduino.ino"
bool checkSlaveStatus(int slaveAddress);
#line 6 "C:\\Users\\LapTechnology\\Desktop\\Arduino fiels\\Masterarduino\\Masterarduino.ino"
void setup() {
  Wire.begin(); 
  Serial.begin(2600); 
}

void loop() {
 
  controlSlave(SLAVE1_ADDRESS);

  
  if (!checkSlaveStatus(SLAVE2_ADDRESS)) {
    Serial.println("ARD2 (Backup Master) is not responding!");
  
  }

  delay(500); 
}


void controlSlave(int slaveAddress) {
  Serial.println("Sending command to ARD1: Turn on LED1");
  Wire.beginTransmission(slaveAddress);
  Wire.write(1); 
  Wire.endTransmission();
  delay(500); 

  Serial.println("Sending command to ARD1: Turn off both LEDs");
  Wire.beginTransmission(slaveAddress);
  Wire.write(0);
  Wire.endTransmission();
  delay(500); 

  Serial.println("Sending command to ARD1: Turn on LED2");
  Wire.beginTransmission(slaveAddress);
  Wire.write(2); 
  Wire.endTransmission();
  delay(500); 

  Serial.println("Sending command to ARD1: Turn off both LEDs");
  Wire.beginTransmission(slaveAddress);
  Wire.write(0); 
  Wire.endTransmission();
  delay(500); 
}


bool checkSlaveStatus(int slaveAddress) {
  Wire.beginTransmission(slaveAddress);
  byte error = Wire.endTransmission();
  return (error == 0); 
}
